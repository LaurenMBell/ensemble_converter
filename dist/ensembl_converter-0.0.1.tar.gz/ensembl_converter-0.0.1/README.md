This is a bioinformatics practice project of Lauren Bell's. It 
is a small package that can convert a gene's Ensembl ID to it's
respective symbol via the Biomart API. She might add more functionality 
later. Who knows. 